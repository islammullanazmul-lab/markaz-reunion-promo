import React from "react";
import { cues } from "../data/cues";
import { theme } from "../theme";
import { S01Hook } from "./S01Hook";
import { S02Intro } from "./S02Intro";
import { S03Years } from "./S03Years";
import { S04Date } from "./S04Date";
import { S05Done } from "./S05Done";
import { S06Hub } from "./S06Hub";
import { S07Today } from "./S07Today";
import { S08Surprise } from "./S08Surprise";
import { S09Waiting } from "./S09Waiting";
import { S10Memory } from "./S10Memory";
import { S11Recap } from "./S11Recap";
import { S12End } from "./S12End";

// Scene = a range of SRT cues. Scene boundaries == cue boundaries; each scene
// enters `lead` frames BEFORE its first cue (visual precedes speech).
const DEFS: { id: string; from: number; to: number; C: React.FC }[] = [
  { id: "hook", from: 1, to: 1, C: S01Hook },
  { id: "intro", from: 2, to: 3, C: S02Intro },
  { id: "years", from: 4, to: 4, C: S03Years },
  { id: "date", from: 5, to: 5, C: S04Date },
  { id: "done", from: 6, to: 6, C: S05Done },
  { id: "hub", from: 7, to: 7, C: S06Hub },
  { id: "today", from: 8, to: 8, C: S07Today },
  { id: "surprise", from: 9, to: 9, C: S08Surprise },
  { id: "waiting", from: 10, to: 10, C: S09Waiting },
  { id: "memory", from: 11, to: 11, C: S10Memory },
  { id: "recap", from: 12, to: 12, C: S11Recap },
  { id: "end", from: 13, to: 13, C: S12End },
];

export const SCENES = DEFS.map((d, i) => {
  const cueStart = cues[d.from - 1].startFrame;
  const start = i === 0 ? 0 : cueStart - theme.frames.lead;
  const end = cues[d.to - 1].endFrame;
  return { ...d, cueStart, start, duration: end - start };
});
