import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { KenBurns, LogoBadge, Panel } from "../components/Common";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";

const Polaroid: React.FC<{ rot: number; delay: number; x: number; y: number; children: React.ReactNode }> = ({ rot, delay, x, y, children }) => (
  <div style={{ position: "absolute", left: x, top: y }}>
    <Entrance delay={delay} y={80} preset="bouncy" from={0.7}>
      <Breathe amp={6} phase={delay * 3}>
        <div style={{ width: 340, height: 410, padding: 16, background: theme.colors.white, borderRadius: 16, boxShadow: theme.shadow.card, transform: `rotate(${rot}deg)` }}>
          <div style={{ width: "100%", height: 300, borderRadius: 8, overflow: "hidden", background: theme.colors.bgAlt, display: "flex", alignItems: "center", justifyContent: "center" }}>{children}</div>
        </div>
      </Breathe>
    </Entrance>
  </div>
);

// Gradient/fluid memory scene with polaroid frames.
export const S10Memory: React.FC = () => {
  const frame = useCurrentFrame();
  const { cue } = useCue();
  const c11 = cue(11);
  const line = interpolate(frame, [c11 + 34, c11 + 54], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <SceneShell>
      <Panel>
        <Sfx at={c11 + 3} name="whoosh" />
        <Sfx at={c11 + 12} name="pop" />
        <Sfx at={c11 + 22} name="thud" vol={0.8} />
        <Polaroid rot={-8} delay={c11 + 8} x={120} y={140}><KenBurns src="portrait.jpg" position="50% 30%" /></Polaroid>
        <Polaroid rot={7} delay={c11 + 14} x={1450} y={110}><KenBurns src="poster.jpg" zoomTo={1.03} pan={0} position="50% 25%" /></Polaroid>
        <Polaroid rot={-4} delay={c11 + 20} x={1380} y={560}><LogoBadge size={270} /></Polaroid>
        <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", paddingRight: 0 }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
            <WordReveal text="সেই দিনটিকে" size={74} delay={c11 + 4} per={5} align="center" color={theme.colors.onPrimaryDim} weight={theme.weight.strong} />
            <WordReveal text="স্মৃতিতে" size={230} delay={c11 + 12} per={5} align="center" color={theme.colors.onPrimary} />
            <WordReveal text="অমর" size={230} delay={c11 + 18} per={5} align="center" color={theme.colors.accent} />
            <div style={{ width: 520, height: 12, borderRadius: 8, background: theme.colors.accent, transformOrigin: "left center", transform: `scaleX(${line})`, marginTop: 6 }} />
          </div>
        </AbsoluteFill>
      </Panel>
    </SceneShell>
  );
};
