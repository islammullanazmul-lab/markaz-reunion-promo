import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { GlassCard, Sparkle } from "../components/Common";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";

// Statement Card: "সবচেয়ে সুন্দর চমক".
export const S08Surprise: React.FC = () => {
  const { cue } = useCue();
  const c9 = cue(9);
  const sp = [
    { x: 330, y: 250, s: 70, d: 22, c: theme.colors.accent },
    { x: 1600, y: 280, s: 100, d: 28, c: theme.colors.primary },
    { x: 1500, y: 800, s: 64, d: 34, c: theme.colors.accent },
    { x: 380, y: 790, s: 90, d: 40, c: theme.colors.primary },
    { x: 960, y: 180, s: 54, d: 46, c: theme.colors.accent },
  ];
  return (
    <SceneShell>
      <Sfx at={c9 + 3} name="pop" />
      <Sfx at={c9 + 30} name="chime" />
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center" }}>
        <Entrance delay={c9 + 2} y={60} from={0.9}>
          <Breathe amp={5}>
            <GlassCard style={{ width: 1500, padding: "80px 70px", display: "flex", flexDirection: "column", alignItems: "center", gap: 10 }}>
              <WordReveal text="আপনার একটি উপস্থিতিই" size={100} delay={c9 + 8} per={4} align="center" color={theme.colors.textDim} />
              <WordReveal text="সবচেয়ে সুন্দর চমক" size={150} delay={c9 + 20} per={5} align="center" color={theme.colors.primary} marks={{ "চমক": 14 }} />
            </GlassCard>
          </Breathe>
        </Entrance>
        {sp.map((p, i) => <Sparkle key={i} x={p.x} y={p.y} size={p.s} delay={c9 + p.d} color={p.c} />)}
      </AbsoluteFill>
    </SceneShell>
  );
};
