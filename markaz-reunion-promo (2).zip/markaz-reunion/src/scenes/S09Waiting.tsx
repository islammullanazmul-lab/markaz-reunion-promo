import React from "react";
import { AbsoluteFill, interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";
import { Sparkle } from "../components/Common";
import { PersonIcon } from "../components/Icons";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";

// Row of classmates; one empty slot glows for "আপনি".
export const S09Waiting: React.FC = () => {
  const frame = useCurrentFrame();
  const { cue } = useCue();
  const c10 = cue(10);
  const pulse = 0.5 + 0.5 * Math.sin(frame / 7);
  return (
    <SceneShell>
      <Sfx at={c10 + 3} name="whoosh" vol={0.8} />
      <Sfx at={c10 + 14} name="pop" />
      <Sfx at={c10 + 34} name="chime" />
      <AbsoluteFill style={{ alignItems: "center" }}>
        <div style={{ marginTop: 130 }}>
          <WordReveal text="অপেক্ষায় পুরনো সহপাঠী" size={112} delay={c10 + 2} per={5} align="center" color={theme.colors.primary} />
        </div>
        <div style={{ display: "flex", gap: 50, marginTop: 150 }}>
          {[0, 1, 2, 3, 4].map((i) => {
            const you = i === 2;
            const d = c10 + 12 + i * 5;
            return (
              <Entrance key={i} delay={d} y={50} preset="bouncy" from={0.7}>
                <Breathe amp={you ? 3 : 6} phase={i * 11}>
                  <div style={{ width: 240, height: 300, borderRadius: theme.radius.tile, display: "flex", alignItems: "flex-end", justifyContent: "center", overflow: "hidden", position: "relative",
                    background: you ? theme.colors.accentSoft : theme.colors.card, border: you ? `5px dashed ${theme.colors.accent}` : `3px solid ${theme.colors.cardBorder}`,
                    boxShadow: you ? `0 0 ${30 + pulse * 50}px ${theme.colors.accentGlow}` : theme.shadow.soft }}>
                    <PersonIcon size={210} color={you ? theme.colors.accent : theme.colors.primary} />
                  </div>
                </Breathe>
                <div style={{ marginTop: 26, textAlign: "center", height: 80, fontFamily: theme.fonts.display, fontWeight: theme.weight.title, fontSize: 64, lineHeight: 1.3, color: theme.colors.primary, opacity: you ? interpolate(frame, [c10 + 34, c10 + 46], [0, 1], { extrapolateLeft: "clamp", extrapolateRight: "clamp", easing: theme.ease.out }) : 0 }}>আপনি</div>
              </Entrance>
            );
          })}
        </div>
        <Sparkle x={960} y={430} size={60} delay={c10 + 38} color={theme.colors.accent} />
        <Sparkle x={1130} y={470} size={40} delay={c10 + 44} color={theme.colors.primary} />
      </AbsoluteFill>
    </SceneShell>
  );
};
