import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Chip, LogoBadge } from "../components/Common";
import { Breathe, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";
import { toBn } from "../utils";

// Clean closing: logo + brand + date.
export const S12End: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cue } = useCue();
  const c13 = cue(13);
  const p = spring({ frame: frame - c13 - 2, fps, config: theme.spring.bouncy });
  return (
    <SceneShell exit={20}>
      <Sfx at={c13 + 2} name="chime" />
      <Sfx at={c13 + 6} name="whoosh" vol={0.6} />
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", gap: 36 }}>
        <Breathe amp={6} style={{ opacity: Math.min(1, p * 1.5), transform: `scale(${interpolate(p, [0, 1], [0.5, 1])})` }}>
          <LogoBadge size={380} />
        </Breathe>
        <WordReveal text="মারকাযুল লুগাতিল আরাবিয়্যাহ বাংলাদেশ" size={70} delay={c13 + 10} per={4} align="center" color={theme.colors.primary} />
        <WordReveal text={`চতুর্থ ছাত্র পুনর্মিলনী · ${toBn(14)} নভেম্বর, শনিবার`} size={52} delay={c13 + 22} per={3} align="center" color={theme.colors.textDim} weight={theme.weight.strong} />
        <Chip text="ওয়াসসালামু আলাইকুম" size={44} tone="soft" delay={c13 + 40} />
      </AbsoluteFill>
    </SceneShell>
  );
};
