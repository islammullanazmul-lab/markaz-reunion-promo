import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { KenBurns } from "../components/Common";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";
import { toBn } from "../utils";

// Glossy mockup: tilted poster card + calendar tile (১৪ নভেম্বর, শনিবার) + headline.
export const S04Date: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cue } = useCue();
  const c5 = cue(5);
  const posterP = spring({ frame: frame - c5 - 6, fps, config: theme.spring.smooth });
  const day = Math.round(interpolate(spring({ frame: frame - c5 - 14, fps, config: { damping: 30, stiffness: 70, mass: 1 } }), [0, 1], [1, 14]));
  return (
    <SceneShell>
      <Sfx at={c5 + 2} name="whoosh" />
      <Sfx at={c5 + 14} name="pop" />
      <Sfx at={c5 + 30} name="click" />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", padding: "0 110px", gap: 50 }}>
        <div style={{ width: 760, display: "flex", flexDirection: "column", gap: 34 }}>
          <WordReveal text="চতুর্থ" size={170} delay={c5 + 2} per={5} color={theme.colors.primary} />
          <WordReveal text="পুনর্মিলনী" size={170} delay={c5 + 8} per={5} marks={{ "পুনর্মিলনী": 22 }} />
          <Entrance delay={c5 + 14} y={36} preset="snappy">
            <div style={{ display: "flex", alignItems: "stretch", gap: 28, marginTop: 6 }}>
              <div style={{ width: 250, borderRadius: theme.radius.tile, overflow: "hidden", background: theme.colors.white, boxShadow: theme.shadow.card, textAlign: "center", fontFamily: theme.fonts.display }}>
                <div style={{ background: theme.colors.primary, color: theme.colors.onPrimary, fontSize: 44, fontWeight: theme.weight.strong, padding: "8px 0", lineHeight: 1.3 }}>নভেম্বর</div>
                <div style={{ color: theme.colors.text, fontSize: 150, fontWeight: theme.weight.title, lineHeight: 1.25 }}>{toBn(day)}</div>
              </div>
              <div style={{ display: "flex", alignItems: "center", fontFamily: theme.fonts.display, fontSize: 104, fontWeight: theme.weight.title, color: theme.colors.text, lineHeight: 1.3 }}>শনিবার</div>
            </div>
          </Entrance>
        </div>
        <div style={{ flex: 1, perspective: 1800, display: "flex", justifyContent: "center" }}>
          <Breathe amp={8}>
            <div style={{ width: 880, height: 550, borderRadius: 40, overflow: "hidden", border: `8px solid ${theme.colors.white}`, boxShadow: theme.shadow.card, opacity: Math.min(1, posterP * 1.4), transform: `translateX(${interpolate(posterP, [0, 1], [160, 0])}px) rotateY(${interpolate(posterP, [0, 1], [-34, -9])}deg) rotateX(3deg) scale(${interpolate(posterP, [0, 1], [0.9, 1])})` }}>
              <KenBurns src="poster.jpg" zoomTo={1.08} pan={-20} />
            </div>
          </Breathe>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
