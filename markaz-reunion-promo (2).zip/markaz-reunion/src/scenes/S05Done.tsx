import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Chip, Panel } from "../components/Common";
import { CheckIcon } from "../components/Icons";
import { Breathe, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";

// Checklist moment on a hero-color panel.
export const S05Done: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cue } = useCue();
  const c6 = cue(6);
  const badge = spring({ frame: frame - c6 - 4, fps, config: theme.spring.bouncy });
  const tick = interpolate(frame, [c6 + 16, c6 + 32], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <SceneShell>
      <Panel>
        <Sfx at={c6 + 4} name="pop" />
        <Sfx at={c6 + 16} name="click" />
        <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", padding: "0 170px", gap: 120 }}>
          <div style={{ position: "relative", width: 440, height: 440, display: "flex", alignItems: "center", justifyContent: "center" }}>
            {[0, 1].map((i) => {
              const t = Math.max(0, Math.min(1, (frame - c6 - 18 - i * 12) / 36));
              return <div key={i} style={{ position: "absolute", inset: 0, borderRadius: "50%", border: `4px solid ${theme.colors.accentGlow}`, opacity: 1 - t, transform: `scale(${1 + t * 0.7})` }} />;
            })}
            <Breathe amp={5}>
              <div style={{ width: 400, height: 400, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: `0 0 90px ${theme.colors.accentGlow}`, opacity: Math.min(1, badge * 1.5), transform: `scale(${interpolate(badge, [0, 1], [0.4, 1])})` }}>
                <CheckIcon size={250} color={theme.colors.primaryDeep} progress={tick} />
              </div>
            </Breathe>
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 26, alignItems: "flex-start" }}>
            <Chip text="আলহামদুলিল্লাহ" size={48} tone="dark" delay={c6 + 4} />
            <WordReveal text="রেজিস্ট্রেশন" size={168} delay={c6 + 8} per={5} color={theme.colors.onPrimary} />
            <WordReveal text="সম্পন্ন" size={168} delay={c6 + 14} per={5} color={theme.colors.accent} />
          </div>
        </AbsoluteFill>
      </Panel>
    </SceneShell>
  );
};
