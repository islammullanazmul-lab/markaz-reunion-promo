import React from "react";
import { AbsoluteFill, Img, interpolate, spring, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Chip } from "../components/Common";
import { PersonIcon } from "../components/Icons";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";

const CX = 960, CY = 575, RX = 560, RY = 245, NODES = 6;

// Hub and Spoke: me (hub) ↔ loved ones.
export const S06Hub: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cue } = useCue();
  const c7 = cue(7);
  const hub = spring({ frame: frame - c7 - 2, fps, config: theme.spring.bouncy });
  const pts = Array.from({ length: NODES }).map((_, i) => {
    const a = ((30 + i * 60) * Math.PI) / 180;
    return { x: CX + RX * Math.cos(a), y: CY + RY * Math.sin(a) };
  });
  return (
    <SceneShell>
      <Sfx at={c7 + 2} name="pop" />
      <Sfx at={c7 + 16} name="pop" rate={1.08} vol={0.8} />
      <Sfx at={c7 + 40} name="chime" vol={0.7} />
      <AbsoluteFill>
        <svg width={1920} height={1080} style={{ position: "absolute", inset: 0 }}>
          {pts.map((p, i) => {
            const d = interpolate(frame - (c7 + 10 + i * 5), [0, 18], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
            const t = (((frame - c7 - 28 - i * 7) % 40) + 40) % 40 / 40;
            const on = frame > c7 + 28 + i * 7;
            return (
              <g key={i}>
                <line x1={CX} y1={CY} x2={p.x} y2={p.y} stroke={theme.colors.primaryMid} strokeWidth={5} strokeDasharray="2 14" strokeLinecap="round" opacity={d} />
                {on && <circle cx={p.x + (CX - p.x) * t} cy={p.y + (CY - p.y) * t} r={9} fill={theme.colors.accent} />}
              </g>
            );
          })}
        </svg>
        <div style={{ position: "absolute", top: 70, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
          <WordReveal text="প্রিয় ও স্নেহের মানুষ" size={84} delay={c7 + 4} per={5} align="center" color={theme.colors.primary} />
        </div>
        {pts.map((p, i) => (
          <div key={i} style={{ position: "absolute", left: p.x - 75, top: p.y - 75 }}>
            <Entrance delay={c7 + 12 + i * 5} y={30} preset="bouncy" from={0.5}>
              <Breathe amp={5} phase={i * 14}>
                <div style={{ width: 150, height: 150, borderRadius: "50%", background: i === 2 ? theme.colors.accent : theme.colors.card, border: `3px solid ${theme.colors.cardBorder}`, boxShadow: theme.shadow.soft, display: "flex", alignItems: "flex-end", justifyContent: "center", overflow: "hidden" }}>
                  <PersonIcon size={120} color={i === 2 ? theme.colors.primaryDeep : theme.colors.primary} />
                </div>
              </Breathe>
            </Entrance>
          </div>
        ))}
        <div style={{ position: "absolute", left: CX - 150, top: CY - 150, width: 300, height: 300, opacity: Math.min(1, hub * 1.5), transform: `scale(${interpolate(hub, [0, 1], [0.4, 1])})` }}>
          <Breathe amp={4}>
            <div style={{ width: 300, height: 300, borderRadius: "50%", overflow: "hidden", border: `10px solid ${theme.colors.primary}`, boxShadow: `0 0 80px ${theme.colors.glow}` }}>
              <Img src={staticFile("portrait.jpg")} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "50% 30%" }} />
            </div>
          </Breathe>
        </div>
        <div style={{ position: "absolute", bottom: 54, left: 0, right: 0, display: "flex", justifyContent: "center" }}>
          <Chip text="সাক্ষাতের অপেক্ষা" size={46} tone="accent" delay={c7 + 30} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
