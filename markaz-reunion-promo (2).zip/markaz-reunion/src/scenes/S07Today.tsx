import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Chip } from "../components/Common";
import { ArrowIcon, CheckIcon } from "../components/Icons";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";

const Box: React.FC<{ progress: number; fg: string; border: string; fill: string }> = ({ progress, fg, border, fill }) => (
  <div style={{ width: 120, height: 120, borderRadius: 32, border: `7px solid ${border}`, background: `rgba(0,0,0,0)`, position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
    <div style={{ position: "absolute", inset: -7, borderRadius: 32, background: fill, opacity: progress }} />
    <div style={{ position: "relative" }}><CheckIcon size={84} color={fg} progress={progress} /></div>
  </div>
);

// Before / After split: "এখনো করেননি" → "আজই করে ফেলুন".
export const S07Today: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cue } = useCue();
  const c8 = cue(8);
  const checked = interpolate(frame, [c8 + 36, c8 + 52], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const press = spring({ frame: frame - c8 - 56, fps, config: theme.spring.bouncy });
  return (
    <SceneShell>
      <Sfx at={c8 + 4} name="pop" />
      <Sfx at={c8 + 22} name="whoosh" vol={0.7} />
      <Sfx at={c8 + 38} name="click" />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 60 }}>
        <Entrance delay={c8 + 2} x={-120} y={20}>
          <div style={{ width: 700, height: 520, borderRadius: theme.radius.card, background: theme.colors.card, border: `3px dashed ${theme.colors.primaryMid}`, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 40, opacity: 0.92 }}>
            <Box progress={0} fg={theme.colors.primary} border={theme.colors.primaryMid} fill={theme.colors.primary} />
            <WordReveal text="এখনো করেননি" size={86} delay={c8 + 8} per={5} align="center" color={theme.colors.textDim} />
          </div>
        </Entrance>
        <Entrance delay={c8 + 14} y={10} preset="bouncy" from={0.5}>
          <div style={{ width: 120, height: 120, borderRadius: "50%", background: theme.colors.accent, display: "flex", alignItems: "center", justifyContent: "center", boxShadow: theme.shadow.soft }}>
            <ArrowIcon size={70} color={theme.colors.primaryDeep} />
          </div>
        </Entrance>
        <Entrance delay={c8 + 20} x={120} y={20}>
          <Breathe amp={5}>
            <div style={{ width: 700, height: 520, borderRadius: theme.radius.card, background: `linear-gradient(135deg, ${theme.colors.primaryDeep}, ${theme.colors.primary})`, boxShadow: theme.shadow.card, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 34 }}>
              <Box progress={checked} fg={theme.colors.primaryDeep} border={theme.colors.onPrimary} fill={theme.colors.accent} />
              <WordReveal text="আজই করে ফেলুন" size={86} delay={c8 + 24} per={5} align="center" color={theme.colors.onPrimary} accentWords={["আজই"]} accentColor={theme.colors.accent} />
              <div style={{ opacity: Math.min(1, press * 1.4), transform: `scale(${interpolate(press, [0, 1], [0.6, 1])})` }}>
                <div style={{ padding: "12px 52px", borderRadius: theme.radius.pill, background: theme.colors.accent, color: theme.colors.primaryDeep, fontFamily: theme.fonts.body, fontWeight: theme.weight.title, fontSize: 46, lineHeight: 1.3 }}>রেজিস্ট্রেশন</div>
              </div>
            </div>
          </Breathe>
        </Entrance>
      </AbsoluteFill>
    </SceneShell>
  );
};
