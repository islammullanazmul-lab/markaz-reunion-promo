import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { Chip, GlassCard } from "../components/Common";
import { CalendarIcon, PinIcon, StarIcon } from "../components/Icons";
import { Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";
import { toBn } from "../utils";

const Tile: React.FC<{ delay: number; icon: React.ReactNode; big: string; small?: string }> = ({ delay, icon, big, small }) => (
  <Entrance delay={delay} y={60} preset="snappy">
    <GlassCard style={{ width: 520, height: 330, display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", gap: 14, borderRadius: theme.radius.tile }}>
      <div style={{ width: 110, height: 110, borderRadius: "50%", background: theme.colors.primarySoft, display: "flex", alignItems: "center", justifyContent: "center" }}>{icon}</div>
      <div style={{ fontFamily: theme.fonts.display, fontWeight: theme.weight.title, fontSize: 62, lineHeight: 1.3, color: theme.colors.text, textAlign: "center" }}>{big}</div>
      {small && <div style={{ fontFamily: theme.fonts.body, fontWeight: theme.weight.strong, fontSize: 46, lineHeight: 1.3, color: theme.colors.primary }}>{small}</div>}
    </GlassCard>
  </Entrance>
);

// Checklist / Recap grid.
export const S11Recap: React.FC = () => {
  const { cue } = useCue();
  const c12 = cue(12);
  return (
    <SceneShell>
      <Sfx at={c12 + 2} name="whoosh" vol={0.8} />
      <Sfx at={c12 + 20} name="pop" />
      <AbsoluteFill style={{ alignItems: "center", justifyContent: "center", gap: 70 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 40 }}>
          <WordReveal text="দেখা হবে পুনর্মিলনীতে" size={112} delay={c12 + 2} per={4} align="center" color={theme.colors.primary} />
        </div>
        <div style={{ display: "flex", gap: 44 }}>
          <Tile delay={c12 + 14} icon={<CalendarIcon size={70} color={theme.colors.primary} />} big={`${toBn(14)} নভেম্বর`} small="শনিবার" />
          <Tile delay={c12 + 19} icon={<PinIcon size={70} color={theme.colors.primary} />} big="মারকায প্রাঙ্গণ" />
          <Tile delay={c12 + 24} icon={<StarIcon size={64} color={theme.colors.accent} />} big="চতুর্থ" small="পুনর্মিলনী" />
        </div>
        <Chip text="ইনশাআল্লাহ" size={62} tone="accent" delay={c12 + 34} />
      </AbsoluteFill>
    </SceneShell>
  );
};
