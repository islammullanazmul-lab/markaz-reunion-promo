import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Chip } from "../components/Common";
import { SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";
import { toBn } from "../utils";

const R = 300, SW = 34, N = 6;
const arc = (a0: number, a1: number) => {
  const p = (a: number) => [R * Math.cos(((a - 90) * Math.PI) / 180), R * Math.sin(((a - 90) * Math.PI) / 180)];
  const [x0, y0] = p(a0), [x1, y1] = p(a1);
  return `M ${x0} ${y0} A ${R} ${R} 0 0 1 ${x1} ${y1}`;
};

// Data Dashboard: counter ৬ with six arc segments lighting up (the only number = script's "৬ বছর").
export const S03Years: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { cue } = useCue();
  const c4 = cue(4);
  const ring = spring({ frame: frame - c4, fps, config: theme.spring.smooth });
  const count = interpolate(spring({ frame: frame - c4 - 8, fps, config: { damping: 30, stiffness: 60, mass: 1 } }), [0, 1], [0, N]);
  return (
    <SceneShell>
      <Sfx at={c4 + 4} name="pop" />
      <Sfx at={c4 + 10} name="tick" />
      <Sfx at={c4 + 22} name="whoosh" vol={0.7} />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 70 }}>
        <div style={{ width: 520, display: "flex", justifyContent: "flex-end", textAlign: "right", flexDirection: "column", alignItems: "flex-end", gap: 20 }}>
          <Chip text="আলহামদুলিল্লাহ" size={40} tone="soft" delay={c4 + 4} />
          <WordReveal text="একই প্রতিষ্ঠানে" size={104} delay={c4 + 8} per={5} align="flex-end" maxWidth={520} />
        </div>
        <div style={{ position: "relative", width: 700, height: 700, display: "flex", alignItems: "center", justifyContent: "center", opacity: Math.min(1, ring * 1.4), transform: `scale(${interpolate(ring, [0, 1], [0.8, 1])})` }}>
          <svg width={700} height={700} viewBox={`${-350} ${-350} 700 700`} style={{ position: "absolute" }}>
            <circle r={R} fill={theme.colors.card} stroke={theme.colors.cardBorder} strokeWidth={2} />
            {Array.from({ length: N }).map((_, i) => {
              const on = interpolate(frame - (c4 + 10 + i * 6), [0, 10], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
              const a0 = i * 60 + 5, a1 = i * 60 + 55;
              return (
                <g key={i}>
                  <path d={arc(a0, a1)} stroke={theme.colors.primarySoft} strokeWidth={SW} strokeLinecap="round" fill="none" />
                  <path d={arc(a0, a1)} stroke={i === N - 1 ? theme.colors.accent : theme.colors.primary} strokeWidth={SW} strokeLinecap="round" fill="none" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - on} />
                </g>
              );
            })}
          </svg>
          <div style={{ position: "relative", textAlign: "center", fontFamily: theme.fonts.display, color: theme.colors.primary, lineHeight: 1 }}>
            <div style={{ fontSize: 330, fontWeight: theme.weight.title, lineHeight: 1.1 }}>{toBn(Math.round(count))}</div>
            <div style={{ fontSize: 96, fontWeight: theme.weight.title, color: theme.colors.text, lineHeight: 1.2 }}>বছর</div>
          </div>
        </div>
        <div style={{ width: 520, display: "flex", flexDirection: "column", gap: 20 }}>
          <WordReveal text="শিক্ষকতার দায়িত্ব" size={104} delay={c4 + 16} per={5} maxWidth={520} color={theme.colors.primary} />
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
