import React from "react";
import { AbsoluteFill } from "remotion";
import { theme } from "../theme";
import { Chip, KenBurns, LogoBadge } from "../components/Common";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";
import { useCue } from "../data/sceneContext";
import { toBn } from "../utils";

// Glossy ID-card intro: portrait + name (cue 2), batch & department (cue 3).
export const S02Intro: React.FC = () => {
  const { cue } = useCue();
  const c2 = cue(2), c3 = cue(3);
  return (
    <SceneShell>
      <Sfx at={c2 + 3} name="pop" />
      <Sfx at={c2 + 14} name="whoosh" vol={0.8} />
      <Sfx at={c3 + 2} name="pop" rate={1.06} />
      <Sfx at={c3 + 12} name="chime" vol={0.8} />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", padding: "0 130px", gap: 110 }}>
        <Entrance delay={c2} x={-90} y={30} from={0.9}>
          <Breathe amp={6}>
            <div style={{ position: "relative", width: 640, height: 780 }}>
              <div style={{ position: "absolute", inset: 0, transform: "translate(26px, 26px)", borderRadius: 64, background: theme.colors.primary, opacity: 0.9 }} />
              <div style={{ position: "absolute", inset: 0, borderRadius: 64, overflow: "hidden", border: `8px solid ${theme.colors.white}`, boxShadow: theme.shadow.card }}>
                <KenBurns src="portrait.jpg" zoomTo={1.1} pan={-18} position="50% 35%" />
              </div>
            </div>
          </Breathe>
        </Entrance>
        <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 30, alignItems: "flex-start" }}>
          <Chip text="প্রিয় সহপাঠী ও শিক্ষার্থীবৃন্দ" size={42} tone="soft" delay={c2 + 6} />
          <WordReveal text="ইমরান হাসান" size={158} delay={c2 + 12} per={6} marks={{ "হাসান": 14 }} />
          <div style={{ display: "flex", alignItems: "center", gap: 22, marginTop: 14 }}>
            <Chip text={`${toBn(2)}য় ব্যাচ`} size={50} tone="accent" delay={c3 + 2} />
            <Chip text="ছাত্র" size={50} tone="soft" delay={c3 + 6} />
          </div>
          <Chip text="আরবি ভাষা ও সাহিত্য গবেষণা বিভাগ" size={46} tone="glass" delay={c3 + 10}>
            <span style={{ display: "inline-flex", width: 76, height: 76, marginLeft: -26 }}><LogoBadge size={76} /></span>
          </Chip>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
