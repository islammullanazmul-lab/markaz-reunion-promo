import React from "react";
import { AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { Chip, LogoBadge } from "../components/Common";
import { Breathe, Entrance, SceneShell, WordReveal } from "../components/Motion";
import { Sfx } from "../components/Sfx";

// Kinetic Typography hook: greeting + logo with ripple rings.
export const S01Hook: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const logo = spring({ frame: frame - 6, fps, config: theme.spring.bouncy });
  return (
    <SceneShell>
      <Sfx at={4} name="whoosh" />
      <Sfx at={8} name="thud" vol={0.8} />
      <Sfx at={14} name="chime" />
      <AbsoluteFill style={{ flexDirection: "row", alignItems: "center", padding: "0 130px" }}>
        <div style={{ width: 1000, display: "flex", flexDirection: "column", gap: 28 }}>
          <WordReveal text="আসসালামু" size={210} delay={2} per={5} color={theme.colors.primary} />
          <WordReveal text="আলাইকুম" size={210} delay={8} per={5} />
          <div style={{ marginTop: 10 }}><Chip text="ওয়ারাহমাতুল্লাহ" size={54} tone="accent" delay={20} /></div>
        </div>
        <div style={{ flex: 1, display: "flex", alignItems: "center", justifyContent: "center", position: "relative" }}>
          {[0, 1, 2].map((i) => {
            const t = ((frame - 10 - i * 18) % 54) / 54;
            const on = frame > 10 + i * 18;
            return <div key={i} style={{ position: "absolute", width: 560, height: 560, borderRadius: "50%", border: `4px solid ${theme.colors.primaryMid}`, opacity: on ? interpolate(t, [0, 1], [0.7, 0]) : 0, transform: `scale(${interpolate(t, [0, 1], [0.9, 1.7])})` }} />;
          })}
          <Breathe amp={7} style={{ opacity: Math.min(1, logo * 1.5), transform: `scale(${interpolate(logo, [0, 1], [0.5, 1])}) rotate(${interpolate(logo, [0, 1], [-25, 0])}deg)` }}>
            <LogoBadge size={540} />
          </Breathe>
        </div>
      </AbsoluteFill>
    </SceneShell>
  );
};
