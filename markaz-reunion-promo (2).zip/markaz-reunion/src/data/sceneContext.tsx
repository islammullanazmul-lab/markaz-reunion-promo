import React, { createContext, useContext } from "react";
import { cues } from "./cues";

type Ctx = { start: number; duration: number };
const SceneCtx = createContext<Ctx>({ start: 0, duration: 1 });

export const SceneProvider: React.FC<Ctx & { children: React.ReactNode }> = ({ start, duration, children }) => (
  <SceneCtx.Provider value={{ start, duration }}>{children}</SceneCtx.Provider>
);

/** Scene-local frame at which SRT cue n (1-based) starts. */
export const useCue = () => {
  const { start, duration } = useContext(SceneCtx);
  return {
    duration,
    cue: (n: number) => cues[n - 1].startFrame - start,
    cueEnd: (n: number) => cues[n - 1].endFrame - start,
  };
};
export const useSceneDuration = () => useContext(SceneCtx).duration;
