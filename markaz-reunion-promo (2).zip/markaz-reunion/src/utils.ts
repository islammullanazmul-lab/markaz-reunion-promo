const BN = ["০", "১", "২", "৩", "৪", "৫", "৬", "৭", "৮", "৯"];
export const toBn = (n: number | string) =>
  String(n).replace(/[0-9]/g, (d) => BN[Number(d)]);
