import React from "react";
import { AbsoluteFill, Composition, Sequence } from "remotion";
import { FPS, HEIGHT, WIDTH } from "./config";
import { TOTAL_FRAMES } from "./data/cues";
import { SceneProvider } from "./data/sceneContext";
import { Grade, BgMesh, Grain, Vignette } from "./components/Layers";
import { PreviewAudio } from "./components/PreviewAudio";
import { Sfx } from "./components/Sfx";
import { Sweep } from "./components/Sweep";
import { SCENES } from "./scenes";

export const Main: React.FC = () => (
  <AbsoluteFill>
    <BgMesh />
    {SCENES.map((s) => (
      <Sequence key={s.id} from={s.start} durationInFrames={s.duration} layout="none">
        <SceneProvider start={s.start} duration={s.duration}>
          <s.C />
        </SceneProvider>
      </Sequence>
    ))}
    {SCENES.slice(1).map((s) => (
      <Sequence key={`sw-${s.id}`} from={s.cueStart - 11} durationInFrames={16} layout="none">
        <Sweep />
        <Sfx at={9} name="whoosh" vol={0.75} />
      </Sequence>
    ))}
    <Grade />
    <Grain />
    <Vignette />
    <PreviewAudio />
  </AbsoluteFill>
);

export const RemotionRoot: React.FC = () => (
  <Composition id="Main" component={Main} durationInFrames={TOTAL_FRAMES} fps={FPS} width={WIDTH} height={HEIGHT} />
);
