import { loadFont } from "@remotion/google-fonts/HindSiliguri";

// Hind Siliguri: correct Bengali conjuncts (যুক্তাক্ষর), heavy weights for titles.
export const { fontFamily } = loadFont("normal", {
  weights: ["500", "600", "700"],
  subsets: ["bengali", "latin"],
});
