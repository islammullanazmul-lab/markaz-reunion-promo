// Video-wide constants and switches. Timing itself comes ONLY from the SRT (src/data/cues.ts).
export const FPS = 30;
export const WIDTH = 1920;
export const HEIGHT = 1080;

// Voiceover (public/voiceover.mp3) – preview helper only.
export const VOICEOVER_FILE = "voiceover.mp3";
// false (default): the voiceover plays in Remotion Studio preview only and is NOT mixed into the MP4 render.
// true: the voiceover is also mixed into the rendered MP4.
export const VOICEOVER_IN_RENDER = false;
