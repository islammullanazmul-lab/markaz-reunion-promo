// Single source of truth: colors, fonts, easings, spring presets, sizes.
// Palette = scheme 6 "Soft Sky Cream". Components never contain raw color codes.
import { Easing } from "remotion";
import { fontFamily } from "./fonts";

export const theme = {
  colors: {
    bg: "#EEF6FA",
    bgAlt: "#E1EEF5",
    primary: "#0E5675", // THE hero color
    primaryDeep: "#093B52",
    accent: "#F2A03D",
    text: "#12303F",
    textDim: "#4E6A79",
    onPrimary: "#F4FAFD",
    white: "#FFFFFF",
    card: "rgba(255,255,255,0.82)",
    cardBorder: "rgba(14,86,117,0.14)",
    primarySoft: "rgba(14,86,117,0.10)",
    primaryMid: "rgba(14,86,117,0.26)",
    accentSoft: "rgba(242,160,61,0.40)",
    accentGlow: "rgba(242,160,61,0.50)",
    glow: "rgba(14,86,117,0.35)",
    shadow: "rgba(18,48,63,0.30)",
    vignette: "rgba(18,48,63,0.14)",
    onPrimaryDim: "rgba(244,250,253,0.74)",
    onPrimarySoft: "rgba(244,250,253,0.14)",
    onPrimaryLine: "rgba(244,250,253,0.28)",
  },
  fonts: {
    display: `${fontFamily}, "Noto Sans Bengali", "Nirmala UI", sans-serif`,
    body: `${fontFamily}, "Noto Sans Bengali", "Nirmala UI", sans-serif`,
  },
  weight: { title: 700, strong: 600, body: 500 },
  radius: { card: 44, tile: 32, pill: 999 },
  shadow: {
    card: "0 44px 90px -28px rgba(18,48,63,0.34), 0 10px 28px -10px rgba(18,48,63,0.16)",
    soft: "0 22px 50px -22px rgba(18,48,63,0.30)",
  },
  ease: {
    out: Easing.bezier(0.16, 1, 0.3, 1),
    inOut: Easing.bezier(0.83, 0, 0.17, 1),
    in: Easing.bezier(0.7, 0, 0.84, 0),
  },
  spring: {
    snappy: { damping: 14, stiffness: 160, mass: 0.6 },
    smooth: { damping: 20, stiffness: 90, mass: 1 },
    bouncy: { damping: 11, stiffness: 170, mass: 0.7 },
  },
  // frame-level conventions (all small offsets are relative to cues, never absolute times)
  frames: { lead: 5, exit: 9, sfxLead: 3 },
} as const;
