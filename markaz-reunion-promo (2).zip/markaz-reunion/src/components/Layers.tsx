import React from "react";
import { AbsoluteFill, useCurrentFrame } from "remotion";
import { theme } from "../theme";

// Subtle 8-point-star lattice (Islamic geometric feel), drawn in SVG.
export const StarPattern: React.FC<{ color: string; opacity: number; size?: number }> = ({ color, opacity, size = 150 }) => {
  const h = size / 2;
  return (
    <svg width="100%" height="100%" style={{ position: "absolute", inset: 0, opacity }}>
      <defs>
        <pattern id={`star-${color.replace(/[^a-z0-9]/gi, "")}`} width={size} height={size} patternUnits="userSpaceOnUse">
          <rect x={h * 0.3} y={h * 0.3} width={size - h * 0.6} height={size - h * 0.6} fill="none" stroke={color} strokeWidth={2} />
          <rect x={h * 0.3} y={h * 0.3} width={size - h * 0.6} height={size - h * 0.6} fill="none" stroke={color} strokeWidth={2}
            transform={`rotate(45 ${h} ${h})`} />
        </pattern>
      </defs>
      <rect width="100%" height="100%" fill={`url(#star-${color.replace(/[^a-z0-9]/gi, "")})`} />
    </svg>
  );
};

export const BgMesh: React.FC = () => {
  const frame = useCurrentFrame();
  const d1 = Math.sin(frame / 55) * 60;
  const d2 = Math.cos(frame / 70) * 50;
  return (
    <AbsoluteFill style={{ background: theme.colors.bg }}>
      <StarPattern color={theme.colors.primary} opacity={0.07} />
      <div style={{ position: "absolute", width: 1300, height: 1300, borderRadius: "50%", top: -560, left: -380 + d1, filter: "blur(40px)",
        background: `radial-gradient(circle, ${theme.colors.primaryMid}, transparent 62%)` }} />
      <div style={{ position: "absolute", width: 1000, height: 1000, borderRadius: "50%", bottom: -480, right: -300 - d2, filter: "blur(60px)",
        background: `radial-gradient(circle, ${theme.colors.accentSoft}, transparent 64%)` }} />
    </AbsoluteFill>
  );
};

export const Grade: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none" }}>
    <AbsoluteFill style={{ backgroundColor: theme.colors.primary, mixBlendMode: "soft-light", opacity: 0.12 }} />
    <AbsoluteFill style={{ background: `linear-gradient(180deg, ${theme.colors.primarySoft}, transparent 28%, transparent 74%, ${theme.colors.primarySoft})` }} />
  </AbsoluteFill>
);

export const Grain: React.FC = () => {
  const frame = useCurrentFrame();
  const noise = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='220' height='220'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='2'/%3E%3C/filter%3E%3Crect width='220' height='220' filter='url(%23n)' opacity='0.5'/%3E%3C/svg%3E")`;
  return (
    <AbsoluteFill style={{ pointerEvents: "none", backgroundImage: noise, backgroundSize: "220px",
      backgroundPosition: `${(frame * 7) % 220}px ${(frame * 13) % 220}px`, opacity: 0.05, mixBlendMode: "multiply" }} />
  );
};

export const Vignette: React.FC = () => (
  <AbsoluteFill style={{ pointerEvents: "none", background: `radial-gradient(ellipse at center, transparent 58%, ${theme.colors.vignette} 100%)` }} />
);
