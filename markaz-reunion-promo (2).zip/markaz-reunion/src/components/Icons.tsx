import React from "react";

type P = { size: number; color: string; progress?: number };

export const CheckIcon: React.FC<P> = ({ size, color, progress = 1 }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none">
    <path d="M22 53 L43 73 L79 29" stroke={color} strokeWidth={13} strokeLinecap="round" strokeLinejoin="round"
      strokeDasharray={100} strokeDashoffset={100 * (1 - progress)} pathLength={100} />
  </svg>
);
export const PersonIcon: React.FC<P> = ({ size, color }) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <circle cx="50" cy="34" r="17" fill={color} />
    <path d="M16 88 C16 64 32 54 50 54 C68 54 84 64 84 88 Z" fill={color} />
  </svg>
);
export const CalendarIcon: React.FC<P> = ({ size, color }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round">
    <rect x="14" y="22" width="72" height="64" rx="12" />
    <path d="M14 42 H86 M34 12 V30 M66 12 V30" />
    <circle cx="36" cy="62" r="3" fill={color} /><circle cx="50" cy="62" r="3" fill={color} /><circle cx="64" cy="62" r="3" fill={color} />
  </svg>
);
export const PinIcon: React.FC<P> = ({ size, color }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" stroke={color} strokeWidth={7} strokeLinecap="round" strokeLinejoin="round">
    <path d="M50 90 C28 66 20 54 20 40 A30 30 0 0 1 80 40 C80 54 72 66 50 90 Z" />
    <circle cx="50" cy="40" r="11" />
  </svg>
);
export const StarIcon: React.FC<P> = ({ size, color }) => (
  <svg width={size} height={size} viewBox="0 0 100 100">
    <path d="M50 4 C54 34 66 46 96 50 C66 54 54 66 50 96 C46 66 34 54 4 50 C34 46 46 34 50 4 Z" fill={color} />
  </svg>
);
export const ArrowIcon: React.FC<P> = ({ size, color }) => (
  <svg width={size} height={size} viewBox="0 0 100 100" fill="none" stroke={color} strokeWidth={9} strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 50 H78 M56 28 L78 50 L56 72" />
  </svg>
);
