import React from "react";
import { Audio, Sequence, staticFile } from "remotion";
import { theme } from "../theme";

const LEN: Record<string, number> = { pop: 0.22, click: 0.12, tick: 0.1, whoosh: 0.7, chime: 0.5, thud: 0.38 };
const BASE: Record<string, number> = { pop: 0.34, click: 0.3, tick: 0.26, whoosh: 0.34, chime: 0.3, thud: 0.3 };
export type SfxName = keyof typeof LEN;

/** Plays a short SFX so that it starts `sfxLead` frames BEFORE the visual lands (at = landing frame, scene-local). */
export const Sfx: React.FC<{ at: number; name: SfxName; vol?: number; rate?: number }> = ({ at, name, vol = 1, rate = 1 }) => {
  const from = Math.max(0, Math.round(at) - theme.frames.sfxLead);
  return (
    <Sequence from={from} durationInFrames={Math.ceil(LEN[name] * 30 / rate) + 2} layout="none">
      <Audio src={staticFile(`sfx/${name}.wav`)} volume={BASE[name] * vol} playbackRate={rate} />
    </Sequence>
  );
};
