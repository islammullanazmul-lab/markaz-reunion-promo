import React from "react";
import { interpolate, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { useSceneDuration } from "../data/sceneContext";

type Preset = keyof typeof theme.spring;

/** Premium entrance: opacity + translate + scale together (never a lone fade). */
export const Entrance: React.FC<{
  delay?: number; x?: number; y?: number; from?: number; preset?: Preset;
  style?: React.CSSProperties; children: React.ReactNode;
}> = ({ delay = 0, x = 0, y = 40, from = 0.94, preset = "smooth", style, children }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = spring({ frame: frame - delay, fps, config: theme.spring[preset] });
  return (
    <div style={{ opacity: Math.min(1, p * 1.4), transform: `translate(${interpolate(p, [0, 1], [x, 0])}px, ${interpolate(p, [0, 1], [y, 0])}px) scale(${interpolate(p, [0, 1], [from, 1])})`, ...style }}>
      {children}
    </div>
  );
};

/** Word-by-word stagger. Splits ONLY on spaces – Bengali conjuncts are never broken. */
export const WordReveal: React.FC<{
  text: string; size: number; delay?: number; per?: number; color?: string; weight?: number;
  align?: "flex-start" | "center" | "flex-end"; maxWidth?: number; accentWords?: string[]; accentColor?: string;
  marks?: Record<string, number>;
}> = ({ text, size, delay = 0, per = 4, color = theme.colors.text, weight = theme.weight.title, align = "flex-start", maxWidth, accentWords = [], accentColor = theme.colors.primary, marks = {} }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const words = text.split(" ");
  return (
    <div style={{ display: "flex", flexWrap: "wrap", justifyContent: align, columnGap: Math.round(size * 0.24), rowGap: 0, maxWidth, fontFamily: theme.fonts.display, fontSize: size, fontWeight: weight, lineHeight: 1.3, letterSpacing: 0, color }}>
      {words.map((w, i) => {
        const p = spring({ frame: frame - delay - i * per, fps, config: theme.spring.snappy });
        const markDelay = marks[w];
        const mp = markDelay === undefined ? 0 : interpolate(frame - (delay + i * per + markDelay), [0, 16], [0, 1], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
        return (
          <span key={i} style={{ position: "relative", display: "inline-block", opacity: Math.min(1, p * 1.3), transform: `translateY(${interpolate(p, [0, 1], [34, 0])}px) scale(${interpolate(p, [0, 1], [0.95, 1])})`, color: accentWords.includes(w) ? accentColor : color }}>
            {markDelay !== undefined && (
              <span style={{ position: "absolute", left: -8, right: -8, bottom: "10%", height: "36%", borderRadius: 14, background: theme.colors.accentSoft, transformOrigin: "left center", transform: `scaleX(${mp})`, zIndex: 0 }} />
            )}
            <span style={{ position: "relative", zIndex: 1 }}>{w}</span>
          </span>
        );
      })}
    </div>
  );
};

/** Idle breathing wrapper for anything that stays on screen. */
export const Breathe: React.FC<{ amp?: number; speed?: number; phase?: number; children: React.ReactNode; style?: React.CSSProperties }> = ({ amp = 6, speed = 30, phase = 0, children, style }) => {
  const frame = useCurrentFrame();
  const y = Math.sin((frame + phase) / speed) * amp;
  const s = 1 + Math.sin((frame + phase) / (speed * 0.8)) * 0.012;
  return <div style={{ transform: `translateY(${y}px) scale(${s})`, ...style }}>{children}</div>;
};

/** Scene wrapper: faster exit than entrance (translate + scale + opacity). */
export const SceneShell: React.FC<{ children: React.ReactNode; exit?: number }> = ({ children, exit = theme.frames.exit }) => {
  const frame = useCurrentFrame();
  const dur = useSceneDuration();
  const t = interpolate(frame, [dur - exit, dur - 1], [0, 1], { easing: theme.ease.in, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", inset: 0, opacity: 1 - t, transform: `translateY(${-30 * t}px) scale(${1 - 0.02 * t})` }}>{children}</div>
  );
};

/** Ease helper for 0→1 progress. */
export const useProgress = (start: number, length: number, easing: (n: number) => number = theme.ease.out) => {
  const frame = useCurrentFrame();
  return interpolate(frame, [start, start + length], [0, 1], { easing, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
};
