import React from "react";
import { interpolate, useCurrentFrame } from "remotion";
import { theme } from "../theme";

/** Scene transition: a hero→accent band whips across; the cut is hidden behind it. 16 frames. */
export const Sweep: React.FC = () => {
  const frame = useCurrentFrame();
  const x = interpolate(frame, [0, 16], [-900, 2500], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ position: "absolute", top: -120, left: 0, width: 620, height: 1320, transform: `translateX(${x}px) skewX(-14deg)`, filter: "blur(3px)", background: `linear-gradient(90deg, ${theme.colors.accent}, ${theme.colors.primary} 70%)`, opacity: 0.96 }} />
  );
};
