import React from "react";
import { AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame, useVideoConfig } from "remotion";
import { theme } from "../theme";
import { StarPattern } from "./Layers";
import { Entrance } from "./Motion";

export const Chip: React.FC<{ text: string; size?: number; tone?: "soft" | "accent" | "glass" | "dark"; delay?: number; x?: number; y?: number; children?: React.ReactNode }> =
  ({ text, size = 44, tone = "soft", delay = 0, x = 0, y = 30, children }) => {
    const c = theme.colors;
    const map = {
      soft: { bg: c.primarySoft, fg: c.primary, bd: "transparent" },
      accent: { bg: c.accent, fg: c.primaryDeep, bd: "transparent" },
      glass: { bg: c.card, fg: c.text, bd: c.cardBorder },
      dark: { bg: c.onPrimarySoft, fg: c.onPrimary, bd: c.onPrimaryLine },
    }[tone];
    return (
      <Entrance delay={delay} x={x} y={y} preset="snappy">
        <div style={{ display: "inline-flex", alignItems: "center", gap: 18, padding: `${size * 0.26}px ${size * 0.7}px`, borderRadius: theme.radius.pill, background: map.bg, color: map.fg, border: `2px solid ${map.bd}`, fontFamily: theme.fonts.body, fontWeight: theme.weight.strong, fontSize: size, lineHeight: 1.3, letterSpacing: 0, boxShadow: tone === "glass" ? theme.shadow.soft : "none" }}>
          {children}{text}
        </div>
      </Entrance>
    );
  };

export const GlassCard: React.FC<{ style?: React.CSSProperties; children: React.ReactNode }> = ({ style, children }) => (
  <div style={{ background: theme.colors.card, border: `2px solid ${theme.colors.cardBorder}`, borderRadius: theme.radius.card, boxShadow: theme.shadow.card, ...style }}>{children}</div>
);

/** Logo shown undistorted inside a circle. */
export const LogoBadge: React.FC<{ size: number }> = ({ size }) => (
  <div style={{ width: size, height: size, borderRadius: "50%", boxShadow: theme.shadow.card, background: theme.colors.white, display: "flex", alignItems: "center", justifyContent: "center" }}>
    <Img src={staticFile("logo.png")} style={{ width: size, height: size, objectFit: "contain", borderRadius: "50%" }} />
  </div>
);

/** Still image with Ken Burns drift. */
export const KenBurns: React.FC<{ src: string; zoomTo?: number; pan?: number; position?: string; style?: React.CSSProperties }> = ({ src, zoomTo = 1.1, pan = -24, position = "center", style }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const k = interpolate(frame, [0, fps * 5], [0, 1], { easing: theme.ease.inOut, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  return (
    <div style={{ width: "100%", height: "100%", overflow: "hidden", ...style }}>
      <Img src={staticFile(src)} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: position, transform: `scale(${1 + (zoomTo - 1) * k}) translateX(${pan * k}px)` }} />
    </div>
  );
};

/** Full-bleed hero-color panel (revealed with an expanding circle). */
export const Panel: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const frame = useCurrentFrame();
  const r = interpolate(frame, [0, 22], [0, 1500], { easing: theme.ease.out, extrapolateLeft: "clamp", extrapolateRight: "clamp" });
  const d = Math.sin(frame / 50) * 40;
  return (
    <AbsoluteFill style={{ clipPath: `circle(${r}px at 50% 50%)` }}>
      <AbsoluteFill style={{ background: `linear-gradient(135deg, ${theme.colors.primaryDeep}, ${theme.colors.primary})` }} />
      <StarPattern color={theme.colors.onPrimary} opacity={0.06} />
      <div style={{ position: "absolute", width: 900, height: 900, borderRadius: "50%", right: -200 + d, top: -300, filter: "blur(60px)", background: `radial-gradient(circle, ${theme.colors.accentSoft}, transparent 65%)` }} />
      <div style={{ position: "absolute", width: 800, height: 800, borderRadius: "50%", left: -260 - d, bottom: -360, filter: "blur(70px)", background: `radial-gradient(circle, ${theme.colors.onPrimarySoft}, transparent 65%)` }} />
      {children}
    </AbsoluteFill>
  );
};

export const Sparkle: React.FC<{ x: number; y: number; size: number; delay: number; color: string }> = ({ x, y, size, delay, color }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const p = Math.max(0, Math.min(1, (frame - delay) / 14));
  const tw = 1 + Math.sin((frame - delay) / 7) * 0.18;
  return (
    <div style={{ position: "absolute", left: x - size / 2, top: y - size / 2, width: size, height: size, opacity: p, transform: `scale(${p * tw}) rotate(${(frame - delay) * 1.5}deg)` }}>
      <svg width={size} height={size} viewBox="0 0 100 100"><path d="M50 4 C54 34 66 46 96 50 C66 54 54 66 50 96 C46 66 34 54 4 50 C34 46 46 34 50 4 Z" fill={color} /></svg>
    </div>
  );
};
