import React, { useEffect, useState } from "react";
import { Audio, continueRender, delayRender, getRemotionEnvironment, staticFile } from "remotion";
import { VOICEOVER_FILE, VOICEOVER_IN_RENDER } from "../config";

/** Plays public/voiceover.mp3 if it exists; silently does nothing if not.
 *  While rendering it is OFF unless VOICEOVER_IN_RENDER = true (src/config.ts). */
export const PreviewAudio: React.FC = () => {
  const enabled = !getRemotionEnvironment().isRendering || VOICEOVER_IN_RENDER;
  const [handle] = useState(() => (enabled ? delayRender("voiceover check") : null));
  const [ok, setOk] = useState(false);
  useEffect(() => {
    if (handle === null) return;
    let alive = true;
    fetch(staticFile(VOICEOVER_FILE), { method: "HEAD" })
      .then((r) => {
        const ct = r.headers.get("content-type") || "";
        if (alive && r.ok && /audio|mpeg|octet/i.test(ct)) setOk(true);
      })
      .catch(() => undefined)
      .finally(() => continueRender(handle));
    return () => { alive = false; };
  }, [handle]);
  return enabled && ok ? <Audio src={staticFile(VOICEOVER_FILE)} /> : null;
};
