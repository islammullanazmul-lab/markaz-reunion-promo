#!/usr/bin/env python3
"""Synthesizes the small UI/motion-graphics SFX kit into public/sfx/*.wav (deterministic, no downloads)."""
import numpy as np, wave, os
from scipy.signal import butter, sosfilt

SR = 48000
rng = np.random.default_rng(7)
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "public", "sfx")
os.makedirs(OUT, exist_ok=True)
t_ = lambda d: np.arange(int(SR * d)) / SR

def lp(x, f):  return sosfilt(butter(2, f, "low", fs=SR, output="sos"), x)
def hp(x, f):  return sosfilt(butter(2, f, "high", fs=SR, output="sos"), x)
def bp(x, a, b): return sosfilt(butter(2, [a, b], "band", fs=SR, output="sos"), x)

def env(n, attack, decay_tau):
    t = np.arange(n) / SR
    a = np.minimum(1, t / max(attack, 1e-4)) ** 2
    return a * np.exp(-t / decay_tau)

def mini_reverb(x, mix=0.14):
    y = x.copy()
    for d, g in ((0.011, .55), (0.023, .38), (0.037, .25), (0.053, .15)):
        k = int(SR * d); y[k:] += x[:-k] * g * mix * 3
    return y

def finish(x, fade=0.012):
    x = lp(x, 9000)
    x = mini_reverb(x)
    n = int(SR * fade); x[-n:] *= np.linspace(1, 0, n)
    return x

def pop():
    t = t_(0.22); f = 170 + 520 * np.exp(-t * 38)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return finish(np.sin(ph) * env(len(t), 0.003, 0.05))

def click():
    t = t_(0.12)
    n = hp(rng.standard_normal(len(t)), 2200) * env(len(t), 0.0015, 0.007)
    b = np.sin(2 * np.pi * 1500 * t) * env(len(t), 0.001, 0.012) * 0.35
    return finish(n + b)

def tick():
    t = t_(0.10)
    n = bp(rng.standard_normal(len(t)), 2500, 6000) * env(len(t), 0.001, 0.010)
    return finish(n)

def whoosh():
    d = 0.7; t = t_(d); n = rng.standard_normal(len(t)); out = np.zeros(len(t))
    seg = 24
    for i in range(seg):
        a, b = int(len(t) * i / seg), int(len(t) * (i + 1) / seg)
        c = 500 + 2600 * (i / seg) ** 1.4
        out[a:b] = bp(n, c * .6, c * 1.5)[a:b]
    e = np.sin(np.pi * np.clip(t / d, 0, 1)) ** 2
    return finish(out * e)

def chime():
    t = t_(0.5); x = np.zeros(len(t))
    for f, g, tau in ((880, 1, .16), (1320, .45, .11), (1760, .22, .08), (2640, .08, .05)):
        x += g * np.sin(2 * np.pi * f * t) * np.exp(-t / tau)
    x *= np.minimum(1, t / 0.006) ** 2
    return finish(x)

def thud():
    t = t_(0.38); f = 48 + 60 * np.exp(-t * 14)
    ph = 2 * np.pi * np.cumsum(f) / SR
    return finish(lp(np.sin(ph) * env(len(t), 0.010, 0.09), 400))

TARGET_RMS, PEAK_LIMIT = 0.115, 0.70
for name, fn in (("pop", pop), ("click", click), ("tick", tick), ("whoosh", whoosh), ("chime", chime), ("thud", thud)):
    x = fn()
    x = x / np.sqrt(np.mean(x[np.abs(x) > 1e-4] ** 2))   # level-match by RMS
    x *= TARGET_RMS
    pk = np.max(np.abs(x))
    if pk > PEAK_LIMIT: x *= PEAK_LIMIT / pk
    pcm = np.int16(np.clip(x, -1, 1) * 32767)
    with wave.open(os.path.join(OUT, name + ".wav"), "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm.tobytes())
    print(f"{name:7s} dur={len(x)/SR:.2f}s peak={np.max(np.abs(pcm))/32767:.3f} rms={np.sqrt(np.mean((pcm/32767.0)**2)):.3f} clipped={int(np.sum(np.abs(pcm)>=32767))}")
