# Markaz Reunion – Remotion project

    npm install
    npx remotion studio
    npx remotion render src/index.ts Main out/video.mp4

- Composition ID: `Main` (1920×1080, 30fps, 1530 frames = 51s, derived from the SRT in `src/data/cues.ts`)
- Optional voiceover: put `voiceover.mp3` in `public/` (plays in Studio preview; to mix into the MP4 set `VOICEOVER_IN_RENDER = true` in `src/config.ts`)
- Colors / fonts / easings: `src/theme.ts` · SFX: `public/sfx/*.wav` (regenerate: `python3 tools/make_sfx.py`)
- Font Hind Siliguri is loaded through `@remotion/google-fonts` (needs internet the first time it loads).
